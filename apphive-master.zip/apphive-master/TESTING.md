# Testing

In order to test Pop!_Shop, you must do the following:

```
killall io.elementary.appcenter
sudo apt install pop-shop
io.elementary.appcenter
```

Check the following:

- Search works on the main page and inside a category
- Installing a new application and uninstalling it works
- Viewing installed applications from the Updates menu works
- Right clicking on applications in GNOME Shell and clicking on "Show Details" works for programs with appstream data
